
"one_shot" outputModule template must be manually set in After Effects before running ag_gen_raw_data.jsx


Install the fowllowing modules:

npm install xml2js
npm install xmlbuilder
npm install mongodb
npm install mongoose

The generated template_raw_data_description.xml must be converted to UTF-8 with �ɭ��LBOM <-- Not needed now
