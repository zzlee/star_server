var FMDB = require('./db');

FMDB.test();