//var serverURL = 'http://localhost:3000'; 
//var serverURL = 'http://localhost'; 
//var serverURL = 'http://192.168.5.101';
var serverURL = 'http://192.168.1.7';
